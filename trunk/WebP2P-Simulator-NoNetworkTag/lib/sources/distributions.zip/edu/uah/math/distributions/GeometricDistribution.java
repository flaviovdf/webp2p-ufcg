/*
Copyright (C) 2001  Kyle Siegrist, Dawn Duehring

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but without
any warranty; without even the implied warranty of merchantability or
fitness for a particular purpose. See the GNU General Public License for
more details. You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
package edu.uah.math.distributions;
import java.io.Serializable;

/**
* This class models the geometric distribution with a given success probability.
* This distribution models the trial number of the first success in a sequence
* of Bernoulli trials.
* @author Kyle Siegrist
* @author Dawn Duehring
* @version August, 2003
*/
public class GeometricDistribution extends NegativeBinomialDistribution implements Serializable{

	/**
	* This general constructor creates a new geometric distribution with
	* a specified success probabilitiy
	* @param p the success probability
	*/
	public GeometricDistribution(double p){
		super(1, p);
	}

	/**
	* This default constructor creates a new geometric distribution with parameter 0.5
	*/
	public GeometricDistribution(){
		this(0.5);
	}

	/**
	* This method computes the factorial moment of a specified order.
	* @param k the order
	* @return the factorial moment of order k
	*/
	public double getFactorialMoment(int k){
		double p = getProbability();
		return Functions.factorial(k) * Math.pow(1 - p, k - 1) / Math.pow(p, k);
	}

	/**
	* This method ensures that the number of successes is set at 1.
	* @param k the number of successes
	*/
	public void setSuccesses(int k){
		super.setSuccesses(1);
	}

	/**
	* This method sets the negative binomial parameters, and ensures that the
	* number of successes is set at 1.
	* @param k the number of successes
	* @param p the probability of success
	*/
	public void setParameters(int k, double p){
		super.setParameters(1, p);
	}

	/**
	* This method returns a string that gives the name of the distribution and the values of
	* the parameters.
	* @return a string giving the name of the distribution and the values of the parameters
	*/
	public String toString(){
		return "Geometric distribution [probability = " + getProbability() + "]";
	}
}

