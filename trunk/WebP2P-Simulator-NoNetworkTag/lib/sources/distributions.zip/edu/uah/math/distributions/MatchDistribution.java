/*
Copyright (C) 2001  Kyle Siegrist, Dawn Duehring

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but without
any warranty; without even the implied warranty of merchantability or
fitness for a particular purpose. See the GNU General Public License for
more details. You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
package edu.uah.math.distributions;
import java.io.Serializable;

/**
* This class models the distribution of the number of matches in a random
* permutation.  A match occurs whenever an element is in its natural order.
* @author Kyle Siegrist
* @author Dawn Duehring
* @version August, 2003
*/
public class MatchDistribution extends Distribution implements Serializable{
	private int parameter;

	/**
	* This general constructor creates a new matching distribution with a
	* specified parameter.
	* @param n the number of elements
	*/
	public MatchDistribution(int n){
		setParameter(n);
	}

	/**
	* This default constructor creates a new mathcing distribuiton with
	* parameter 5.
	*/
	public MatchDistribution(){
		this(5);
	}

	/**
	* This method sets the parameter of the distribution.
	* @param n the size of the random permutation
	*/
	public void setParameter(int n){
		if (n < 1) n = 1;
		parameter = n;
		setDomain(0, parameter, 1, DISCRETE);
	}

	/**
	* This method computes the probability density function.
	* @param x a number in the domain {0, 1, 2, ...}
	* @return the probability density at x
	*/
	public double getDensity(double x){
		int k = (int)Math.rint(x);
		double sum = 0;
		int sign = -1;
		for (int j = 0; j <= parameter - k; j++){
			sign = -sign;
			sum = sum + sign / Functions.factorial(j);
		}
		return sum / Functions.factorial(k);
	}

	/**
	* This method gives the maximum value of the probability density function.
	* @return the maximum value of the probability density function
	*/
	public double getMaxDensity(){
		if (parameter == 2) return getDensity(0);
		else return getDensity(1);
	}

	/**
	* This method returns the mean, which is 1, regardless of the parameter
	* value.
	* @return the mean of the distribution
	*/
	public double getMean(){
		return 1;
	}

	/**
	* This method returns the variance, which is 1 regardless of the parameter
	* value.
	* @return the variance of the distribution
	*/
	public double getVariance(){
		return 1;
	}

	/**
	* This method gets the parameter.
	* @return the size of the random permutation
	*/
	public int getParameter(){
		return parameter;
	}

	/**
	* This method simulates a value from the distribution, by generating
	* a random permutation and computing the number of matches.
	*/
	public double simulate(){
		int[] p = Functions.getSample(parameter, parameter, Functions.WITHOUT_REPLACEMENT);
		int matches = 0;
		for (int i = 0; i < parameter; i++) if (p[i] == i + 1) matches++;
		return matches;
	}

	/**
	* This method returns a string that gives the name of the distribution and the values of
	* the parameters.
	* @return a string giving the name of the distribution and the values of the parameters
	*/
	public String toString(){
		return "Matching distribution [parameter = " + parameter + "]";
	}
}

