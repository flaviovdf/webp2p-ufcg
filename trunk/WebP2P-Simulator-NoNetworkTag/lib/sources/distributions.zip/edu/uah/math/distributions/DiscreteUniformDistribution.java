/*
Copyright (C) 2001  Kyle Siegrist, Dawn Duehring

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but without
any warranty; without even the implied warranty of merchantability or
fitness for a particular purpose. See the GNU General Public License for
more details. You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
package edu.uah.math.distributions;
import java.io.Serializable;

/**
* This class models the discrete uniform distribution on a finite set.
* @author Kyle Siegrist
* @author Dawn Duehring
* @version August, 2003
*/
public class DiscreteUniformDistribution extends FiniteDistribution implements Serializable{

	/**
	* This general constructor creates a new discrete uniform distribution
	* on a specified domain.
	* @param a the lower value of the domain
	* @param b the upper value of the domain
	* @param w the  step size of the domain
	*/
	public DiscreteUniformDistribution(double a, double b, double w){
		super(a, b, w);
	}

	/**
	* This default constructor creates a new discrete uniform distribution
	* on {1, 2, 3, 4, 5, 6}.
	*/
	public DiscreteUniformDistribution(){
		this(1, 6, 1);
	}

	/**
	* This method simulates a value from the distribution.
	* @return a simulated value from the distribution
	*/
	public double simulate(){
		Domain d = getDomain();
		double a = d.getLowerValue(), b = d.getUpperValue();
		double x = a + Math.random() * (b - a);
		return d.getNearestValue(x);
	}

	/**
	* This method sets the probabilities to ensure that the uniform
	* distribution is not changed.
	* @param p the array of probabilities
	*/
	public void setProbabilities(double[] p){}

	/**
	* This method sets the finite distribution parameters to ensure that
	* the uniform distribution is not changed.
	* @param a the lower value
	* @param b the upper value
	* @param w the width
	* @param p the array of probabilities
	*/
	public void setParameters(double a, double b, double w, double[] p){
		setParameters(a, b, w);
	}

	/**
	* This method returns a string that gives the name of the distribution and the values of
	* the parameters.
	* @return a string giving the name of the distribution and the values of the parameters
	*/
	public String toString(){
		return "Discrete uniform distribution [domain = " + getDomain() + "]";
	}

}

