/*
Copyright (C) 2001  Kyle Siegrist, Dawn Duehring

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but without
any warranty; without even the implied warranty of merchantability or
fitness for a particular purpose. See the GNU General Public License for
more details. You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
package edu.uah.math.distributions;
import java.io.Serializable;

/**
* This class defines the chi-square distribution with a specifed degrees of
* freedom parameter.
* @author Kyle Siegrist
* @author Dawn Duehring
* @version August, 2003
*/
public class ChiSquareDistribution extends GammaDistribution implements Serializable{
	private int degrees;

	/**
	* This general constructor creates a new chi-square distribuiton with a
	* specified degrees of freedom parameter.
	* @param n the degrees of freedom
	*/
	public ChiSquareDistribution(int n){
		setDegrees(n);
	}

	/**
	* This default constructor creates a new chi-square distribution with
	* 1 degree of freedom.
	*/
	public ChiSquareDistribution(){
		this(1);
	}

	/**
	* This method sets the degrees of freedom parameter and computes the
	* defaut domain.
	* @param n the degrees of freedom
	*/
	public void setDegrees(int n){
		//Correct invalid parameter
		if (n <= 0) n = 1;
		degrees = n;
		super.setParameters(0.5 * degrees, 2);
	}

	/**
	* This method returns the degrees of freedom parameter.
	* @return the degrees of freedom
	*/
	public int getDegrees(){
		return degrees;
	}

	/**
	* This method simulates a value from the distribuiton, as the sum of squares
	* of independent, standard normal distribution.
	* @return a simulated value form the distribution
	*/
	public double simulate(){
		double V, Z, r, theta;
		V = 0;
		for (int i = 1; i <= degrees; i++){
			r = Math.sqrt(-2 * Math.log(Math.random()));
			theta = 2 * Math.PI * Math.random();
			Z = r * Math.cos(theta);
			V = V + Z * Z;
		}
		return V;
	}

	/**
	* This method sets the shape parameter, which must be n/2, where n is
	* the degrees of freedom.
	* @param k the shape parameter
	*/
	public void setShape(double k){
		super.setShape(0.5 * degrees);
	}

	/**
	* This method sets the scale parameter, which must be 2.
	* @param b the scale parameter
	*/
	public void setScale(double b){
		super.setScale(b);
	}

	/**
	* This method sets the gamma parameters, which must be related to the degrees
	* of freedom.
	* @param k the shape parameter
	* @param b the scale parameter
	*/
	public void setParameters(double k, double b){
		super.setParameters(0.5 * degrees, 2);
	}

	/**
	* This method returns a string that gives the name of the distribution and the values of
	* the parameters.
	* @return a string giving the name of the distribution and the values of the parameters
	*/
	public String toString(){
		return "Chi-squre distribution [degrees of freedom = " + degrees + "]";
	}
}

